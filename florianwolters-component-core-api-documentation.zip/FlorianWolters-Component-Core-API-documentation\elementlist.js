
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","Exception"],["c","FlorianWolters\\Component\\Core\\CharUtils"],["c","FlorianWolters\\Component\\Core\\RandomStringUtils"],["c","FlorianWolters\\Component\\Core\\StringEscapeUtils"],["c","FlorianWolters\\Component\\Core\\StringUtils"],["c","FlorianWolters\\Component\\Core\\WordUtils"],["c","InvalidArgumentException"],["c","LogicException"],["c","OutOfBoundsException"],["c","RuntimeException"]];
